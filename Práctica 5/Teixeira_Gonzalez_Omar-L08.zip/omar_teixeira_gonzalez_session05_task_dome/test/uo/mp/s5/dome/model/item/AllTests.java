package uo.mp.s5.dome.model.item;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
/**
 * Titulo: Clase AllTests
 * 
 * @author Omitg
 * @version 26-02-2021
 */
@RunWith(Suite.class)
@SuiteClasses({SetTitleTest.class, SetBasePriceTest.class})
public class AllTests {

}
