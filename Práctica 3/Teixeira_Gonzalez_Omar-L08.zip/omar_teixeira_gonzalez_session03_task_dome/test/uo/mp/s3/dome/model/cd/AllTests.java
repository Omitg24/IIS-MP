package uo.mp.s3.dome.model.cd;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * T�tulo: Clase AllTests
 * 
 * 
 * @author Omitg
 * @version 18-02-2021
 */

@RunWith(Suite.class)
@SuiteClasses({ CdTest.class, SetCommentTest.class, SetOwnTest.class })
public class AllTests {

}
