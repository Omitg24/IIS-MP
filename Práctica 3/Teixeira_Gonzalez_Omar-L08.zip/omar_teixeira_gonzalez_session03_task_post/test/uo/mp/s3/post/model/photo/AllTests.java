package uo.mp.s3.post.model.photo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Titulo: Clase AllTests
 *  
 * @author Omitg
 * @version 20-02-2021
 */
@RunWith(Suite.class)
@SuiteClasses({ PhotoTest.class , ToStringTest.class })
public class AllTests {

}
