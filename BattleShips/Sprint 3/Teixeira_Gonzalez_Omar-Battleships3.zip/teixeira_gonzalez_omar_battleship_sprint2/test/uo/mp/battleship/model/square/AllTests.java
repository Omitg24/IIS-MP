package uo.mp.battleship.model.square;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Titulo: Clase AllTest
 * 
 * @author Omitg
 * @version 07-03-2021
 */
@RunWith(Suite.class)
@SuiteClasses({ ShootAtTest.class })
public class AllTests {

}
