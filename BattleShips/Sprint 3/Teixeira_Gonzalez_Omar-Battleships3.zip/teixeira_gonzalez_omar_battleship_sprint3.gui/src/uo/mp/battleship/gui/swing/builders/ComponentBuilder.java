package uo.mp.battleship.gui.swing.builders;

import java.awt.Component;

public interface ComponentBuilder {

	Component build();

}
