package uo.mp.battleship.model.boardbuilder;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Titulo: Clase AllTest
 * 
 * @author Omitg
 * @version 12-02-2021
 */
@RunWith(Suite.class)
@SuiteClasses({ BuildTest.class, OfTest.class })
public class AllTests {

}
