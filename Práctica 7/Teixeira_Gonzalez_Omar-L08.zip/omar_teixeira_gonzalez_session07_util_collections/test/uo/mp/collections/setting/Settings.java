package uo.mp.collections.setting;

/**
 * Titulo: Clase Settings
 * 
 * @author Omitg
 * @version 18-03-2021
 */
public class Settings {
	/**
	 * Creaci�n de las listas
	 */
	public static ListFactory factory;

}
