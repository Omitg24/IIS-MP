package uo.mp.s1.game.model.game2048;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s1.game.model.Game2048;

public class IsBoardFullTest {
	/*
	 * Pruebas del m�todo isBoardFull de la clase Game2048:
	 * 1- Matriz completamente llena -> Devuelve true
	 * 2- Matriz parcialmente llena -> Devuelve false
	 * 3- Matriz vac�a -> Devuelve false
	 */
			
	/**
	 * 1- Matriz completamente llena -> Devuelve true
	 */
	@Test
	public void testIsBoardFull() {
		Game2048 game = new Game2048(CodeForTest.FULL); //{{2,2,2},{2,2,2},{2,2,2}}
		assertTrue (game.isBoardFull());
	}
		
	/**
	 * 2- Matriz parcialmente llena -> Devuelve false
	 */
	@Test
	public void testNotIsBoardFull() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL22); //{{2,2,0},{2,2,0},{2,2,0}}
		assertFalse (game.isBoardFull());
	}
	
	/**
	 * 3- Matriz vac�a -> Devuelve false
	 */
	@Test
	public void testEmptyIsBoardFull() {
		Game2048 game = new Game2048 (CodeForTest.EMPTY); //{{0,0,0},{0,0,0},{0,0,0}};
		assertFalse (game.isBoardFull());
	}
}
