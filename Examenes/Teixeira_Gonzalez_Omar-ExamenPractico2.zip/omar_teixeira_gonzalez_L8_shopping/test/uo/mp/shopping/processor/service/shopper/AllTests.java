package uo.mp.shopping.processor.service.shopper;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AddProductsTest.class, CalculateCostTest.class })
public class AllTests {

}
