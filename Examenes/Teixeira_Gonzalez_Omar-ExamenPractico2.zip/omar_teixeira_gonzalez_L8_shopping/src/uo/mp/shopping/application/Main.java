/**
 * 
 */
package uo.mp.shopping.application;

import uo.mp.shopping.processor.ShoppingProcessor;

public class Main {

	
	public static void main(String[] args) {
		new ShoppingProcessor().run();

	}

}
