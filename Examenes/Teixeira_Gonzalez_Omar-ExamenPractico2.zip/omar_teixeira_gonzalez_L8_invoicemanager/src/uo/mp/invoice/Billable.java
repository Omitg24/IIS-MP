package uo.mp.invoice;

public interface Billable {
	
	String getCode();
	
	String getDescription();
	
	double getCost();
	
}
