package uo.mp.exception;

/**
 * Titulo: Clase NotYetImplementedException
 * 
 * @author Omitg
 * @version 07-04-2021
 */
public class NotYetImplementedException extends RuntimeException {
	/**
	 * Atributo que lanza la excepci�n
	 */
	private static final long serialVersionUID = 1L;

}
